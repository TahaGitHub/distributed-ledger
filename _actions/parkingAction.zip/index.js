const request = require('request');

function main(args) {
  const QUERY_URL = `http://${args.info.ip}:${args.info.port}/fdb/pass-app-network/ledger/query`;
  const TRANSACT_URL = `http://${args.info.ip}:${args.info.port}/fdb/pass-app-network/ledger/transact`;

  return new Promise(function(resolve, reject) {
    var d = {
      "select": ["*"],
      "from": ["users/userId" , args.params.userId]
    };
    
    _request(QUERY_URL, 'POST', d).then(res_GetUser => {
      console.log('user 1 state: ', res_GetUser);
      if (res_GetUser.error) {
        resolve({
          state: false,
          error: 'In Get User',
          mes: res_GetUser
        });
      }

      if (res_GetUser.length === 0) {
        resolve({
          state: false,
          mes: "No user found in fluree db"
        });
      }

      if (res_GetUser[0]['users/balance'] >= args.params.amount) {
        d = [{
          _id: ["users/userId", args.params.userId],
          balance: res_GetUser[0]['users/balance'] - args.params.amount
        }];

        _request(TRANSACT_URL, 'POST', d).then(res_transactTransfer => {
          if (res_transactTransfer.error) {
            resolve({
              state: false,
              error: 'In Transact balance',
              mes: res_transactTransfer
            });
          }

          if (res_transactTransfer.status === 200 ) {
            resolve({
              state: true,
              mes: 'User has permission and money'
            });
          } else {
            resolve({
              state: false,
              error: 'In Transact response',
              mes: res_transactTransfer
            });
          }
        });
      } else {
        resolve({
          state: false,
          mes: "No enough money"
        });
      }
    })
  })

  function _request (url, method, body) {
    return new Promise(function(resolve, reject) {
      switch (method) {
        case 'POST':
          request.post(url, { json: body }, function(err, response, body) {
            if (err) {
              reject(err);
            }
            else {
              resolve(body);
            }
          });
          break;
          case 'GET':
            break;
        default:
          break;
      }
    });
  }
}

// main({ params: {
//   userId: "tets 1 postman",
//   amount: 1
// }, info: {
//   ip: "192.168.1.70",
//   port: 31090
// }}).then(console.log)

exports.main = main;
